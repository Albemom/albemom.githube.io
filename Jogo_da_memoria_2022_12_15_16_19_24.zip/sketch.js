// no meu game, falta criar um contador de cartas desviradas e também falta um contador para impedir que mais de duas cartas sejam desviradas por vez.

// meu jogo será um jogo da memoria, com 3 dificuldades (facil,médio e dificil). O objetivo do jogo é encontrar todos os pares de cartas antes que o tempo acabe.obs: conforme a dificuldade aumenta o tempo é menor.

var img_menu
var img_info
var img_creditos
var img_dificuldade
var img_base
var img_gameOver

var tela=0

var borda=-80
var bordaDif=-80 // borda da tela dificuldade

var cartasFacil=['4','3','4','3','2','1','2','1']
var cartasMedio=['A','C','A','B','D','B','C','D']
var cartasDificil=['🙂','🤣','🙂','😡','😔','😡','😔','🤣']

var cartasX=[]
var cartasY=[]

var viradasFacil=[]
var viradasMedio=[]
var viradasDificil=[]

var contVirF=0
var contVirM=0
var contVirD=0

var contagemTempo= false
var contTempo=0

var cronometroFacil=629
var cronometroMedio=479
var cronometroDificil=329

function preload(){
  img_menu=loadImage("menu.png")
  img_creditos=loadImage("créditos.png")
  img_dificuldade=loadImage("dificuldade.png")
  img_base=loadImage("base.png")
  img_gameOver=loadImage("gameOver.png")
  img_info=loadImage("informaçoes.png")
}

function setup(){
  createCanvas(400,400)
  frameRate(30)
  incY=120
  incX=80
  
  xi=50
  yi=100
  
  for(i=0;i<8;i++){
    cartasX[i]=xi
    cartasY[i]=yi
    xi=xi+incX
    if(xi>300){
      yi=yi+incY
      xi=50
    }
    viradasFacil[i]=false
    viradasMedio[i]=false
    viradasDificil[i]=false
  }

}

function desviraCartas(){
  for(i=0;i<8;i++){
      viradasFacil[i]=false
      viradasMedio[i]=false
      viradasDificil[i]=false
  }
}

function draw(){
  if(tela==0){menu()}
  
  if(tela==1){dificuldade()}
  
  if(tela==2){informaçoes()}
  
  if(tela==3){creditos()}
  
  if(tela==4){facil()}
  
  if(tela==5){medio()}
  
  if(tela==6){dificil()}
  
  if(tela==7){gameOver1()}
  
  if(tela!=4){cronometroFacil=629} // zerar o contador quando sair da tela
  
  if(tela!=5){cronometroMedio=479} // zerar o contador quando sair da tela
  
  if(tela!=6){cronometroDificil=329} // zerar o contador quando sair da tela
}

function menu(){
  background(img_menu)
  noFill()
  strokeWeight(4)
  stroke("#9C27B0")
  rect(60, borda,280, 30, 5)
} // tela do menu

function informaçoes(){
  background(img_info)
  textSize(24)
  textAlign(CENTER)
  fill(400)
  noStroke()
  textSize(18)
  text("voltar", 360,390)
  noFill()
  stroke(400)
  strokeWeight(2)
  rect(329, 374,60, 21, 5)
} // tela das infroomações

function creditos(){
  background(img_creditos)
  textAlign(CENTER)
  fill(400)
  noStroke()
  textSize(18)
  text("voltar", 360,390)
  noFill()
  stroke(400)
  strokeWeight(2)
  rect(329, 374,60, 21, 5)
} // tela dos créditos

function dificuldade(){
  background(img_dificuldade)
  textSize(24)
  textAlign(CENTER)
  fill(400)
  noStroke()
  textSize(18)
  text("voltar", 360,390)
  noFill()
  stroke(400)
  strokeWeight(2)
  rect(329, 374,60, 21, 5)
  strokeWeight(4)
  stroke("#9C27B0")
  rect(110, bordaDif,180, 30, 5)
} // tela para escolher a dificuldade

function facil(){
  background(img_base) 
  textAlign(CENTER)
  fill(400)
  noStroke()
  textSize(18)
  text("voltar", 360,390)
  noFill()
  stroke(400)
  strokeWeight(2)
  rect(329, 374,60, 21, 5)
  
  textSize(32)
  for(i=0;i<8;i++){
    rect(cartasX[i],cartasY[i],40,70)
    if(viradasFacil[i]){
      text(cartasFacil[i],cartasX[i]+20,cartasY[i]+45)
    }  
  }
    if(contagemTempo){
    contTempo++ // conta 2 segundos
    if(contTempo>60){
      contagemTempo=false
      desviraCartas()
      contTempo=0
    }
  }
  cronometroFacil--
  if(cronometroFacil<0){
    tela=7
    cronometroFacil=629
  }
  textSize(25)
  noFill()
  text("cronômetro:"+" "+parseInt(cronometroFacil/30),200,40)   // o cronometro para em 20 segundos
} // dificuldade fácil

function medio(){
  background(img_base)
  textSize(24)
  textAlign(CENTER)
  fill(400)
  noStroke()
  textSize(18)
  text("voltar", 360,390)
  noFill()
  stroke(400)
  strokeWeight(2)
  rect(329, 374,60, 21, 5)
  
  textSize(32)
  for(i=0;i<8;i++){
    rect(cartasX[i],cartasY[i],40,70)
    if(viradasMedio[i]){
      text(cartasMedio[i],cartasX[i]+20,cartasY[i]+45)
    }  
  }
    if(contagemTempo){
    contTempo++ // conta 2 segundos
    if(contTempo>60){
      contagemTempo=false
      desviraCartas()
      contTempo=0
    }
  }
  
  cronometroMedio--
  if(cronometroMedio<0){
    tela=7
    cronometroMedio=479
  }
  textSize(25)
  noFill()
  text("cronômetro:"+" "+parseInt(cronometroMedio/30),200,40)  // o cronometro para em 15 segundos
  

} // dificuldade médio

function dificil(){
  background(img_base)
  textSize(24)
  textAlign(CENTER)
  fill(400)
  noStroke()
  textSize(18)
  text("voltar", 360,390)
  noFill()
  stroke(400)
  strokeWeight(2)
  rect(329, 374,60, 21, 5)
  
  textSize(32)

    if(contagemTempo){
    contTempo++ // conta 2 segundos
    if(contTempo>60){
      contagemTempo=false
      desviraCartas()
      contTempo=0
    }
  }
    for(i=0;i<8;i++){
    rect(cartasX[i],cartasY[i],40,70)
    if(viradasDificil[i]){
      text(cartasDificil[i],cartasX[i]+20,cartasY[i]+45)
    }  
  }

  cronometroDificil--
  if(cronometroDificil<0){ 
    tela=7
    cronometroDificil=329
  }
  textSize(25)
  noFill()
  text("cronômetro:"+" "+parseInt(cronometroDificil/30),200,40)  // o cronometro para em 10 segundos
} // dificuldade difícil

function gameOver1(){
  background(img_gameOver)
  textAlign(CENTER)
  fill(400)
  noStroke()
  textSize(18)
  text("voltar", 360,390)
  noFill()
  stroke(400)
  strokeWeight(2)
  rect(329, 374,60, 21, 5)
} // tela para quando perder

function mouseReleased(){
  for(i=0;i<8;i++){
    if(mouseX > cartasX[i] && mouseX < cartasX[i]+40 && mouseY>cartasY[i] && mouseY < cartasY[i]+70){
      contVirF++
      if(contVirF<=2){
        viradasFacil[i]=true
        viradasMedio[i]=true
        viradasDificil[i]=true
      }
      contagemTempo=true
    }
  } // função para desvirar cartas quando forem clickadas
    if(tela==1){
      if(mouseX>=110 && mouseX<=290 && mouseY>=172 && mouseY<=203){tela=4}
      else{
        if(mouseX>=110 && mouseX<=290 && mouseY>=212 && mouseY<=245){tela=5}
        else{
          if(mouseX>=110 && mouseX<=290 && mouseY>=253 && mouseY<=285){tela=6}
      }
    }
  } // função para escolher a dificuldade
}

function mouseMoved() {
  if(mouseX>=60 && mouseX<=340 && mouseY>=173 && mouseY<=203){
    borda=173
  }
  else{
    if(mouseX>=60 && mouseX<=340 && mouseY>=215 && mouseY<=249){
      borda=219
    } 
    else{
      if(mouseX>=60 && mouseX<=340 && mouseY>=260 && mouseY<=293){
        borda=267
      }
    }
  }
  if(tela==1){
      if(mouseX>=110 && mouseX<=290 && mouseY>=172 && mouseY<=203){
        bordaDif=173
  }
  else{
    if(mouseX>=110 && mouseX<=290 && mouseY>=212 && mouseY<=245){
      bordaDif=215
    } 
    else{
      if(mouseX>=110 && mouseX<=290 && mouseY>=253 && mouseY<=285){
        bordaDif=255
      }
    }
  }
  }
} // função para mover a borda da tela menu e dificuldade

function mouseClicked(){
  if(tela==0){
    if(mouseX>=60 && mouseX<=340 && mouseY>=173 && mouseY<=203 && tela==0){tela=1}
    if(mouseX>=60 && mouseX<=340 && mouseY>=215 && mouseY<=249 && tela==0){tela=2}
    if(mouseX>=60 && mouseX<=340 && mouseY>=260 && mouseY<=293 && tela==0){tela=3}
  }
  else{
    if(mouseX>=328 && mouseX<=390 && mouseY>=375 && mouseY<=395){tela=0}
  }
}

